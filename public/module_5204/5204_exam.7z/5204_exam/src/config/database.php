<?php

return [
  'connections' => [
    'mysql' => [
      'driver' => 'mysql',
      'host' => 'localhost',
      'port' => '',
      'dbname' => 'exam',
      'username' => 'homestead',
      'password' => 'secret'
    ]
  ]
];
