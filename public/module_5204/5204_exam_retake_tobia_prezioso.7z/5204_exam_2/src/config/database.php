<?php

return [
  'connections' => [
    'mysql' => [
      'driver' => 'mysql',
      'host' => 'localhost',
      'port' => '',
      'dbname' => 'exam_5204',
      'username' => 'homestead',
      'password' => 'secret'
    ]
  ]
];
