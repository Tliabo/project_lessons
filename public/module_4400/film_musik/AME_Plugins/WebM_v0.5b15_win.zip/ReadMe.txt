WebM Premiere plug-in
by Brendan Bolles <brendan@fnordware.com>

Version 0.5b15 - 4 November 2014


Intro
=====

WebM is a free-as-in-beer, free-as-in-speech video format developed by Google, based on technology they got when they acquired On2 Technologies.  It's really quite awesome.  More info here:

http://www.webmproject.org/


Installation
============

Copy the plug-in to the shared MediaCore directory:

Mac:
WebM Premiere.bundle -> /Library/Application Support/Adobe/Common/Plug-ins/CSX/MediaCore

Win:
WebM.prm -> C:\Program Files\Adobe\Common\Plug-ins\CSX\MediaCore


Replace "CSX" with your version.  For the latest Premiere Pro CC release, it will be "7.0".


Usage
=====

When installed, you'll be able to import a .webm file into Premiere.

Go to File > Export > Media and choose WebM as the format to encode WebM video.

WebM should also appear as a supported format in Adobe Media Encoder.

Most parameters should be pretty self-explanatory.  For quality sliders, higher quality means higher image/qudio quality and bigger files.  (For some reason, FFmpeg uses a quality scale where 0 is the highest quality.  Not this plug-in.)

This plug-in includes the new VP9 codec, but it is in active development at Google and still has a long way to go.  It takes much longer to encode than VP8 and some programs won't be able to read it either.  You probably want to stick with VP8 for now.

If you really want to encode VP9, it is highly recommended that you use Variable Bitrate.  Encoding can be dramatically sped up (at the cost of some quality) by adding "--cpu-used=2" to the custom options field.

The Opus codec is also included.  Like VP9, many readers aren't ready for it yet, so proceed with caution.


Custom arguments
================

The VPX encoder supports many different options, far too many to include in Premiere's interface.  There is a text field provided for entering additional options. So you might put something like "-t 4 --bias-pct=80" in there.  Much more information here:

http://www.webmproject.org/docs/encoder-parameters

The flags are taken from the sample "vpxenc" utility that comes with libvpx.  Here are the supported arguments printed right from vpxenc, many of which I have no clue what they do:


Encoder Global Options:
  -t <arg>, --threads=<arg>            	Max number of threads to use
            --lag-in-frames=<arg>      	Max number of frames to lag

Rate Control Options:
            --drop-frame=<arg>         	Temporal resampling threshold (buf %)
            --resize-allowed=<arg>     	Spatial resampling enabled (bool)
            --resize-up=<arg>          	Upscale threshold (buf %)
            --resize-down=<arg>        	Downscale threshold (buf %)
            --target-bitrate=<arg>     	Bitrate (kbps)
            --min-q=<arg>              	Minimum (best) quantizer
            --max-q=<arg>              	Maximum (worst) quantizer
            --undershoot-pct=<arg>     	Datarate undershoot (min) target (%)
            --overshoot-pct=<arg>      	Datarate overshoot (max) target (%)
            --buf-sz=<arg>             	Client buffer size (ms)
            --buf-initial-sz=<arg>     	Client initial buffer size (ms)
            --buf-optimal-sz=<arg>     	Client optimal buffer size (ms)

Twopass Rate Control Options:
            --bias-pct=<arg>           	CBR/VBR bias (0=CBR, 100=VBR)
            --minsection-pct=<arg>     	GOP min bitrate (% of target)
            --maxsection-pct=<arg>     	GOP max bitrate (% of target)

Keyframe Placement Options:
            --kf-min-dist=<arg>        	Minimum keyframe interval (frames)
            --kf-max-dist=<arg>        	Maximum keyframe interval (frames)
            --disable-kf               	Disable keyframe placement

VP8 Specific Options:
            --cpu-used=<arg>           	CPU Used (-16..16)
            --auto-alt-ref=<arg>       	Enable automatic alt reference frames
            --noise-sensitivity=<arg>  	Noise sensitivity (frames to blur)
            --sharpness=<arg>          	Filter sharpness (0-7)
            --static-thresh=<arg>      	Motion detection threshold
            --token-parts=<arg>        	Number of token partitions to use, log2
            --arnr-maxframes=<arg>     	AltRef Max Frames
            --arnr-strength=<arg>      	AltRef Strength
            --arnr-type=<arg>          	AltRef Type
            --tune=<arg>               	Material to favor
                                       	  psnr, ssim
            --cq-level=<arg>           	Constrained Quality Level
            --max-intra-rate=<arg>     	Max I-frame bitrate (pct)

VP9 Specific Options:
            --cpu-used=<arg>           	CPU Used (-16..16)
            --auto-alt-ref=<arg>       	Enable automatic alt reference frames
            --noise-sensitivity=<arg>  	Noise sensitivity (frames to blur)
            --sharpness=<arg>          	Filter sharpness (0-7)
            --static-thresh=<arg>      	Motion detection threshold
            --tile-columns=<arg>       	Number of tile columns to use, log2
            --tile-rows=<arg>          	Number of tile rows to use, log2
            --arnr-maxframes=<arg>     	AltRef Max Frames
            --arnr-strength=<arg>      	AltRef Strength
            --arnr-type=<arg>          	AltRef Type
            --tune=<arg>               	Material to favor
                                       	  psnr, ssim
            --cq-level=<arg>           	Constrained Quality Level
            --max-intra-rate=<arg>     	Max I-frame bitrate (pct)
            --lossless=<arg>           	Lossless mode



Open Source
===========

Like WebM itself, this plug-in is open source.  See the code and participate here:

http://github.com/fnordware/AdobeWebM 


License
=======

Released under the BSD license:

Copyright (c) 2013, Brendan Bolles
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.