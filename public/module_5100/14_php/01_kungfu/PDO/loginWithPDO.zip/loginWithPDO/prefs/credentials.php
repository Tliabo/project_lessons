<?php
// lokale DB-Credentials
$host = "localhost";
$user = "rene";
$passwd = "espo07";
$dbname = "kungfu";

// DB-Credentials Server
/*
$host = "";
$user = "";
$passwd = "";
$dbname = "";
*/
?>