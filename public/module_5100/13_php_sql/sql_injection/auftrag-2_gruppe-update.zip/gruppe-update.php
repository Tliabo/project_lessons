<?php 
/* AUFGABE: 
 * 1. schaut euch die SQL Befehle an - woher kommen die Daten?
 * 2. entscheidet in der Gruppe, Prepared Statement ja oder nein, und begründet, warum/warum nicht
 * 3. Haltet die Etnscheidung und Begründung als Kommentar im Script fest (bei jedem Statement)
 * 4. wenn ihr möchtet und Zeit habt, schreibt den Code zu einem prepared Statement um, da wo ihr es als notwendig erachtet
 */
require_once('mysqli-connect.php');


 
// Anpassungen vom Admin an einem Produkt speichern
// Prepared Statement?  ..........
// Warum? 				..........
$query = "UPDATE produkt SET titel='Frühlingsaktion: Bunte Cupcakes!' WHERE IDprodukt=5";
$res = mysqli_query($connection, $query);

if($res == true){
	echo 'Änderungen am Produkt wurden gespeichert';
}



// Mehrere, vom Admin gewählte Newsbeiträge in den Papierkorb legen (Admin Aktion)
// Prepared Statement?  ..........
// Warum? 				..........
$query = "UPDATE news SET news_status = -1 WHERE IDprodukt IN (1, 4, 5)";
$res = mysqli_query($connection, $query);

if($res == true){
	echo 'Newsbeiträge wurden in den Papierkorb verschoben';
}

?>